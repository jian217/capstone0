package com.example.summarize;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    Vector lines = new Vector();
    String line = null;
    int line_count = 0;
    double[][] j_index = null;
    double[] tR_value = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = (TextView) findViewById(R.id.text);
        read_articleLines();
        tokenize_words();
        textRank();
        textView.setText(print_lines(5));
    }

    //한 줄씩 읽어서 저장
    public void read_articleLines() {
        try {
            BufferedReader bR = new BufferedReader(new InputStreamReader(getResources().openRawResource(R.raw.article)));

            while ((line = bR.readLine()) != null) {
                lines.add(line);
                line_count++;
            }

            bR.close();
        } catch (IOException e) {
        }
    }

    //문장간 영향력 행사 정의
    //1. 문장 띄어쓰기 단위로 분리
    //2. 두 문장에 어떤 명사가 공통으로 들어있나로 유사도 계산 (Jaccard Index)
    public void tokenize_words() {
        Vector words = new Vector(); // 글 단어 전체
        int word_count = 0;

        //문장별 단어 개수 벡터 값 0으로 초기화
        Vector line_words_number = new Vector(line_count);

        for (int i = 0; i < line_count; i++)
            line_words_number.add(0);

        //문장 띄어쓰기 단위로 분리
        for (int i = 0; i < line_count; i++) {
            int line_word_count = 0;

            StringTokenizer st = new StringTokenizer((String) lines.get(i));

            while (st.hasMoreTokens()) {
                words.add(st.nextToken());
                word_count++;
                line_word_count++;
            }

            line_words_number.set(i, line_word_count);
        }

        //문장간 유사도 배열 값 0으로 초기화
        j_index = new double[line_count][line_count];
        for (int i = 0; i < line_count; i++)
            for (int j = 0; j < line_count; j++)
                j_index[i][j] = 0;

        //두 문장에 어떤 명사가 공통으로 들어있나로 유사도 계산 (Jaccard Index)
        String word1 = "";
        String word2 = "";
        int first_word_index = 0;
        int second_word_index = 0;

        for (int i = 0; i < line_count; i++) {
            second_word_index = first_word_index + (int) line_words_number.get(i);

            for (int j = i + 1; j < line_count; j++) {
                int similarity_count = 0;

                for (int k = 0; k < (int) line_words_number.get(i); k++) {
                    for (int l = 0; l < (int) line_words_number.get(j); l++) {
                        word1 = (String) words.get(first_word_index + k);
                        word2 = (String) words.get(second_word_index + l);

                        if ((word1.length() < 2) || (word2.length() < 2)) {
                            if (word1.equals(word2))
                                similarity_count++;
                        } else {
                            if (word1.substring(0, 2).equals(word2.substring(0, 2))) {
                                //앞 글자 2개 비교해서 같으면 유사 단어 취급 <- 조사, 어미등 나누기 어려움..; 그리고 TextRank에서 딱히 필요 없음.
                                similarity_count++;
                            }
                        }
                    }
                }
                j_index[i][j] = Math.round((similarity_count / (double) ((int) line_words_number.get(i) + (int) line_words_number.get(j) - similarity_count)) * 1000) / 1000.0;
                j_index[j][i] = j_index[i][j];

                second_word_index = second_word_index + (int) line_words_number.get(j);
            }
            first_word_index = first_word_index + (int) line_words_number.get(i);
        }
    }

    //TextRank 수식 구현
    // TR(A) = (1 - 0.85) / lines + 0.85 * ( TR(B) / 문장B의 link 수 + ... )
    public void textRank() {
        int[] link_count = new int[line_count];
        tR_value = new double[line_count];
        double[] tR_before_value = new double[line_count];
        double bracket_value = 0;
        boolean[] no_change = new boolean[line_count];
        int no_change_count = 0;

        //문장별 link 수 -> j_index 값이 0 아님
        for (int i = 0; i < line_count; i++) {
            for (int j = 0; j < line_count; j++) {
                if (j_index[i][j] != 0)
                    link_count[i]++;
            }
        }

        //tR_value 초기화
        for (int i = 0; i < line_count; i++)
            tR_value[i] = Math.round((1 / (double) line_count) * 1000) / 1000.0;

        //수렴할 때까지 반복
        while (true) {
            //TextRank 수식
            for (int i = 0; i < line_count; i++) {
                tR_before_value[i] = tR_value[i];
                no_change[i] = false;
                bracket_value = 0;

                for (int j = 0; j < line_count; j++) {
                    if (j_index[i][j] != 0) {
                        bracket_value = Math.round((bracket_value + tR_value[j] / link_count[j]) * 1000) / 1000.0;
                    }
                }
                tR_value[i] = Math.round((0.15 / line_count + 0.85 * bracket_value) * 100000) / 100000.0;

                if (Math.abs(tR_value[i] - tR_before_value[i]) < 0.00001)
                    no_change[i] = true;
            }

            for (int i = 0; i < line_count; i++)
                if (no_change[i] == true)
                    no_change_count++;

            if (no_change_count == line_count)
                break;
            else
                no_change_count = 0;
        }
    }

    //Rank 값이 높은 순으로 정렬 후 원하는 문장 개수만큼 출력
    public String print_lines(int num) {
        String lines_print = "";

        //정렬
        double tmp = 0;
        String temp = "";

        for (int i = 0; i < line_count; i++) {
            for (int j = 0; j < line_count - 1; j++) {
                if (tR_value[j] < tR_value[j + 1]) {
                    tmp = tR_value[j];
                    temp = (String) lines.get(j);
                    tR_value[j] = tR_value[j + 1];
                    lines.set(j, lines.get(j + 1));
                    tR_value[j + 1] = tmp;
                    lines.set(j + 1, temp);
                }
            }
        }

        //num개의 line 출력
        for (int i = 0; i < num; i++)
            lines_print = lines_print + lines.get(i) + "\n";

        return lines_print;
    }
}


