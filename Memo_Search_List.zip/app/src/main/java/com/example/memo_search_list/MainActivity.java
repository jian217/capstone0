package com.example.memo_search_list;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private PopupWindow memo_writing_window;
    private PopupWindow memo_list_window;
    private PopupWindow memo_showing_window;
    Context context;
    String text;
    EditText editText;
    ListView listview;
    List<String> memoList;
    ArrayAdapter<String> adapter;
    int memo_position;
    String selected_text;

    //툴바 관련 코드
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            //메모 목록
            case R.id.memo_list:
                //메모 목록 열기
                View memoList_popupView = getLayoutInflater().inflate(R.layout.memo_list_popup, null);
                memo_list_window = new PopupWindow(memoList_popupView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
                memo_list_window.setFocusable(true);
                memo_list_window.update();
                memo_list_window.showAtLocation(memoList_popupView, Gravity.CENTER, 0, 0);

                //메모 목록 닫기
                Button close = (Button) memoList_popupView.findViewById(R.id.close_memo_list);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        memo_list_window.dismiss();
                    }
                });

                //메모 목록
                listview = (ListView) memoList_popupView.findViewById(R.id.memo_list_view);
                memoList = new ArrayList<>();

                //파일에서 메모 목록 가져오기
                File[] files = MainActivity.this.getFilesDir().listFiles();
                for (int i = 0; i < files.length; i++) {
                    if (!files[i].isHidden() && files[i].isFile()) {
                        memoList.add(files[i].getName());
                    }
                }

                adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, memoList);
                listview.setAdapter(adapter);

                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                        memo_position = position;
                        //메모 상세 보기
                        View memoShowing_popupView = getLayoutInflater().inflate(R.layout.memo_showing_popup, null);
                        memo_showing_window = new PopupWindow(memoShowing_popupView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        memo_showing_window.setFocusable(true);
                        memo_showing_window.update();
                        memo_showing_window.showAtLocation(memoShowing_popupView, Gravity.CENTER, 0, 0);

                        //메모 타이틀, 내용
                        TextView memo_title = (TextView) memoShowing_popupView.findViewById(R.id.memo_title);
                        TextView memo_content = (TextView) memoShowing_popupView.findViewById(R.id.memo_content);

                        //파일에서 메모 읽기
                        try {
                            StringBuffer data = new StringBuffer();
                            FileInputStream fis = openFileInput(memoList.get(memo_position));
                            BufferedReader buffer = new BufferedReader(new InputStreamReader(fis));
                            memo_title.setText(buffer.readLine());
                            String str = buffer.readLine();
                            while (str != null) {
                                data.append(str + "\n");
                                str = buffer.readLine();
                            }
                            memo_content.setText(data);
                            buffer.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //취소 버튼
                        Button cancel = (Button) memoShowing_popupView.findViewById(R.id.cancel_memo_show);
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                memo_showing_window.dismiss();
                            }
                        });

                        //삭제 버튼
                        Button delete = (Button) memoShowing_popupView.findViewById(R.id.delete_memo);
                        delete.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //삭제 Dialog
                                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                                alert.setTitle("삭제");
                                alert.setMessage("삭제 하시겠습니까?");
                                alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(getApplicationContext(), "삭제되었습니다.", Toast.LENGTH_SHORT).show();

                                        //파일 삭제
                                        File f = new File(MainActivity.this.getFilesDir(), memoList.get(memo_position));
                                        f.delete();

                                        //메모 목록에서 삭제
                                        int count = adapter.getCount();
                                        if (count > 0) {
                                            if (memo_position > -1 && memo_position < count) {
                                                memoList.remove(memo_position);
                                                adapter.notifyDataSetChanged();
                                            }
                                        }
                                        memo_showing_window.dismiss();
                                    }
                                });

                                alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                    }
                                });

                                alert.show();
                            }
                        });
                    }
                });
                return true;
            //요약
            case R.id.summarize_text:
                //요약된 글
                View summary_popupView = getLayoutInflater().inflate(R.layout.summary_popup, null);
                memo_showing_window = new PopupWindow(summary_popupView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                memo_showing_window.setFocusable(true);
                memo_showing_window.update();
                memo_showing_window.showAtLocation(summary_popupView, Gravity.CENTER, 0, 0);

                TextView summary_textView = (TextView) summary_popupView.findViewById(R.id.summary);

                Summarize Summarize = new Summarize();
                Summarize.read_articleLines(context);
                Summarize.tokenize_words();
                Summarize.textRank();
                summary_textView.setText(Summarize.print_lines(3));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    } //툴바 관련 코드 끝

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();

        //Text 영역
        try {
            InputStream in = getResources().openRawResource(R.raw.article);
            byte[] b = new byte[in.available()];
            in.read(b);
            text = new String(b);
        } catch (Exception e) {
        }

        textView = (TextView) findViewById(R.id.text);
        textView.setText(text);
        textView.setCustomSelectionActionModeCallback(new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                try {
                    menu.clear();
                    menu.add(0, R.id.memo, 0, "메모");
                    menu.add(0, R.id.search, 0, "검색");
                } catch (Exception e) {
                }
                return true;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                selected_text = textView.getText().toString().substring(textView.getSelectionStart(), textView.getSelectionEnd());
                switch (item.getItemId()) {
                    //메모
                    case R.id.memo:
                        View memoWriting_popupView = getLayoutInflater().inflate(R.layout.memo_writing_popup, null);
                        memo_writing_window = new PopupWindow(memoWriting_popupView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        memo_writing_window.setFocusable(true);
                        memo_writing_window.update();
                        memo_writing_window.showAtLocation(memoWriting_popupView, Gravity.CENTER, 0, 0);

                        editText = (EditText) memoWriting_popupView.findViewById(R.id.edit_text);

                        //취소 버튼
                        Button cancel = (Button) memoWriting_popupView.findViewById(R.id.cancel_editText);
                        cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                memo_writing_window.dismiss();
                            }
                        });

                        //저장 버튼
                        Button save = (Button) memoWriting_popupView.findViewById(R.id.save_editText);
                        save.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (editText.length() != 0) {
                                    String txt = editText.getText().toString();
                                    long now = System.currentTimeMillis(); // 현재시간 받아오기
                                    String file_name = selected_text + "_" + now + ".txt";
                                    try {
                                        FileOutputStream os = openFileOutput(file_name, MODE_PRIVATE);
                                        os.write(selected_text.getBytes());
                                        os.write("\n".getBytes());
                                        os.write(txt.getBytes());
                                        os.close();

                                        Toast.makeText(getApplicationContext(), "저장되었습니다.", Toast.LENGTH_SHORT).show();
                                    } catch (Exception e) {
                                        Toast.makeText(getApplicationContext(), "저장실패", Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    Toast.makeText(getApplicationContext(), "저장할 내용이 없습니다.", Toast.LENGTH_SHORT).show();
                                }

                                memo_writing_window.dismiss();
                            }
                        });
                        mode.finish();
                        return true;

                    //검색
                    case R.id.search:
                        Intent intentSearch = new Intent(Intent.ACTION_WEB_SEARCH);
                        intentSearch.putExtra(SearchManager.QUERY, selected_text);
                        startActivity(intentSearch);
                        mode.finish();
                        return true;
                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
            }
        }); //Text 영역 끝
    }
}