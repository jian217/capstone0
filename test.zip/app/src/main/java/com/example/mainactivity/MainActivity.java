package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private Button audioFileBtn, fileListBtn, optionBtn, helpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS+"/testDir");
//        if (!path.mkdirs()) {
//            Log.e("FILE", "Directory not created");
//        }else{
//            Toast.makeText(this, "폴더 생성", Toast.LENGTH_SHORT).show();
//        } 나중에 다른 액티비티로 옮길 것

        //이동
        audioFileBtn = findViewById(R.id.audioFileBtn);
        audioFileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent packageContext;
                Intent intent = new Intent(MainActivity.this, FindAudioActivity.class);
                startActivity(intent);
            }
        });

        fileListBtn = findViewById(R.id.fileListBtn);
        fileListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent packageContext;
                Intent intent = new Intent(MainActivity.this, FindTextActivity.class);
                startActivity(intent);
            }
        });

    }
}
